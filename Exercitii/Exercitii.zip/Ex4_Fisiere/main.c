#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    if(argc != 2)
    {
        perror("Programul are nevoie de 1 argument\n");
        exit(-1);
    }
    struct stat buffer;
    int exista = stat(argv[1], &buffer);
    if(exista == 0)
    {
        if(buffer.st_size > 10)
        {
            int fd = open(argv[1], O_WRONLY);
            if(fd < 0)
            {
                perror("Bad file descriptor!\n");
                exit(-1);
            }
            ftruncate(fd, 10);
            close(fd);
        }
    }
    else if(exista == -1)
    {
        int fd = open(argv[1], O_WRONLY | O_CREAT, 0640);
        if(fd < 0)
        {
            perror("Bad file descriptor!\n");
            exit(-1);
        }
        srand(time(NULL));
        for(int i = 0; i < 10; i++)
        {
            char x = rand() % 58 + 65;
            write(fd, &x, sizeof(char));
        }
        close(fd);
    }
    return 0;
}
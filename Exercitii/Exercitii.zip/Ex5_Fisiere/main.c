#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    if(argc != 2)
    {
        perror("Programul necesita calea catre un fisier ca argment!\n");
        exit(-1);
    }
    char buffer[1024];
    int fd = open(argv[1], O_RDWR);
    if(fd < 0)
    {
        perror("Bad file descriptor!\n");
        exit(-1);
    }
    ssize_t read_bytes = read(fd, buffer, 1024);
    fcntl(fd, F_SETFL, __O_NOATIME);
    write(fd, buffer, read_bytes);
    close(fd);
    return 0;
}
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    if(argc != 3)
    {
        perror("Numarul de argumente trebuie sa fie 2!\n");
        exit(-1);
    }
    int fd = open(argv[1], O_RDONLY);
    if(fd != -1)
    {
        return 0;
    }
    fd = open(argv[1], O_CREAT, (mode_t)strtol(argv[2], NULL, 8));
    close(fd);
    return 0;
}
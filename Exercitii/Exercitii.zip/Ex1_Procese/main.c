#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>

int main(int argc, char* argv[])
{
    if(argc != 2)
    {
        perror("Dati un numar de procese ca argument programului!\n");
        exit(-1);
    }
    int n = atoi(argv[1]);
    if(n <= 0)
    {
        perror("Numar de procese invalid!\n");
        exit(-1);
    }
    for(int i = 1; i <= n; i++)
    {
        int pid = fork();
        if(pid == 0)
        {
            printf("%d\n", i);
            exit(0);
        }
    }
    for(int i = 1; i <= n; i++)
    {
        wait(NULL);
    }
    return 0;
}
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    if(argc != 2)
    {
        perror("Trebuie sa existe un argument dat la program!\n");
        exit(-1);
    }
    int fd = open(argv[1], O_RDONLY | __O_NOFOLLOW);
    if(fd < 0)
    {
        perror("Apel esuat! Bad file descriptor sau symlink detectat!\n");
        exit(-1);
    }
    char buff[20];
    lseek(fd, -20, SEEK_END);
    ssize_t read_bytes = read(fd, buff, 20);
    write(STDOUT_FILENO, buff, read_bytes);
    close(fd);
    return 0;
}
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/wait.h>

int main(int argc, char* argv[])
{
    if(argc != 4)
    {
        perror("Dati ca argumente numarul cautat, fisierul cu numere si numarul de procese!\n");
        exit(-1);
    }
    int nr = atoi(argv[1]);
    int n = atoi(argv[3]);
    int pf[2];
    if(pipe(pf) == -1)
    {
        perror("Eroare la crearea pipe-ului!\n");
        exit(-1);
    }
    for(int i = 0; i < n; i++)
    {
        int pid = fork();
        if(pid == 0)
        {
            //TODO
        }
    }
    for(int i = 0; i < n; i++)
    {
        wait(NULL);
    }
    return 0;
}
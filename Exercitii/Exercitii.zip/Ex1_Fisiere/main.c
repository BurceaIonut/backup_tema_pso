#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>

int main()
{
    char buff[16];
    int fd = open("/etc/passwd", O_RDONLY);
    if(fd < 0)
    {
        perror("Bad file descriptor!\n");
        exit(-1);
    }
    ssize_t read_bytes;
    while((read_bytes = read(fd, buff, 16)))
    {
        write(STDOUT_FILENO, buff, read_bytes);
    }
    close(fd);
    return 0;
}
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <stdlib.h>

int open_wrapper(const char* filename, int flags, ...);
ssize_t read_wrapper(unsigned int fd, char* buf, size_t count);
ssize_t write_wrapper(unsigned int fd, const char* buf, size_t count);
int close_wrapper(unsigned int fd);

int main()
{
    //Exemplu de folosire a functiilor wrapper peste open, read, write si close
    char buff[16];
    int fd = open_wrapper("/etc/passwd", O_RDONLY);
    if(fd < 0)
    {
        perror("Bad file descriptor!\n");
        exit(-1);
    }
    ssize_t bytes_read = read_wrapper(fd, buff, 16);
    write_wrapper(STDOUT_FILENO, buff, bytes_read);
    close_wrapper(fd);
    return 0;
}